import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class Project {
    private final String name;
    private final List<Task> tasks;



    public Project(String name, List<Task> tasks) {
        this.name = name;
        this.tasks = tasks;
    }

    /**
     * Schedule all tasks within this project such that they will be completed as early as possible.
     *
     * @return An integer array consisting of the earliest start days for each task.
     */
    public int[] getEarliestSchedule() {
        // TODO: YOUR CODE HERE
        int[] returned = new int[this.tasks.size()];
        Digraph digraph = new Digraph(this.tasks.size());
        for(Task task : this.tasks){
            for (int i = 0; i < task.getDependencies().size(); i++) {
                digraph.addEdge(task.getTaskID(),task.getDependencies().get(i));
            }
        }
        DepthFirstOrder depthFirstOrder = new DepthFirstOrder(digraph);
        Stack<Integer> stack = depthFirstOrder.getReversePost();
        List<Integer> completed = new ArrayList<Integer>();
        while(!stack.isEmpty()){
            List<Integer> currentDependencies = tasks.get(stack.peek()).getDependencies();
            if(currentDependencies.size()==0 || completed.containsAll(currentDependencies)){
                if(currentDependencies.size()==0){
                    returned[stack.peek()]= 0;
                }
                else if (completed.containsAll(currentDependencies)){
                    List<Integer> temp = new ArrayList<>();
                    for (int i = 0; i < currentDependencies.size(); i++) {
                        int add = tasks.get(currentDependencies.get(i)).getDuration() + returned[currentDependencies.get(i)];
                        temp.add(add);
                    }
                    returned[stack.peek()] = Collections.max(temp) ;
                }
            }
            completed.add(stack.pop());
        }
        return returned;
    }

    /**
     * @return the total duration of the project in days
     */
    public int getProjectDuration() {
        int projectDuration = 0;
        // TODO: YOUR CODE HERE
        int[] schedule = this.getEarliestSchedule();
        projectDuration = tasks.get(schedule.length - 1).getDuration() + schedule[schedule.length - 1];
        return projectDuration;
    }

    public static void printlnDash(int limit, char symbol) {
        for (int i = 0; i < limit; i++) System.out.print(symbol);
        System.out.println();
    }

    public void printSchedule(int[] schedule) {
        int limit = 65;
        char symbol = '-';
        printlnDash(limit, symbol);
        System.out.println(String.format("Project name: %s", name));
        printlnDash(limit, symbol);

        // Print header
        System.out.println(String.format("%-10s%-45s%-7s%-5s", "Task ID", "Description", "Start", "End"));
        printlnDash(limit, symbol);
        for (int i = 0; i < schedule.length; i++) {
            Task t = this.tasks.get(i);
            System.out.println(String.format("%-10d%-45s%-7d%-5d", i, t.getDescription(), schedule[i], schedule[i] + t.getDuration()));
        }
        printlnDash(limit, symbol);
        System.out.println(String.format("Project will be completed in %d days.", tasks.get(schedule.length - 1).getDuration() + schedule[schedule.length - 1]));
        printlnDash(limit, symbol);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Project project = (Project) o;

        int equal = 0;

        for (Task otherTask : ((Project) o).tasks) {
            if (tasks.stream().anyMatch(t -> t.equals(otherTask))) {
                equal++;
            }
        }
        return name.equals(project.name) && equal == tasks.size();
    }
}
class Digraph
{
    private final int V;
    private final ArrayList<ArrayList<Integer>> adj;
    public Digraph(int V)
    {
        this.V = V;
        adj = new ArrayList<ArrayList<Integer>>(V);
        for (int v = 0; v < V; v++)
            adj.add(new ArrayList<Integer>());
    }
    public void addEdge(int v, int w)
    {
        adj.get(v).add(w);
    }
    public Iterable<Integer> adj(int v)
    { return adj.get(v); }

    public int V() {
        return this.V;
    }
}
class DepthFirstOrder
{
    private boolean[] marked;
    private Stack<Integer> reversePost;
    public DepthFirstOrder(Digraph G)
    {
        reversePost = new Stack<Integer>();
        marked = new boolean[G.V()];
        for (int v = 0; v < G.V(); v++)
            if (!marked[v]) dfs(G, v);
    }

    public Stack<Integer> getReversePost() {
        Stack<Integer> newOne = new Stack<>();
        while (!reversePost.isEmpty()){
            newOne.push(reversePost.pop());
        }
        return newOne;
    }

    public void dfs(Digraph G, int v)
    {
        marked[v] = true;
        for (int w : G.adj(v))
            if (!marked[w]) dfs(G, w);
        reversePost.push(v);
    }

}
