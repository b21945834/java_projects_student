import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MissionExploration {

    /**
     * Given a Galaxy object, prints the solar systems within that galaxy.
     * Uses exploreSolarSystems() and printSolarSystems() methods of the Galaxy object.
     *
     * @param galaxy a Galaxy object
     */
    public void printSolarSystems(Galaxy galaxy) {
        // TODO: YOUR CODE HERE
        List<SolarSystem> solarSystems = galaxy.exploreSolarSystems();
        galaxy.printSolarSystems(solarSystems);
    }

    /**
     * TODO: Parse the input XML file and return a list of Planet objects.
     *
     * @param filename the input XML file
     * @return a list of Planet objects
     */
    public Galaxy readXML(String filename) {
        List<Planet> planetList = new ArrayList<>();
        DocumentBuilderFactory xml = DocumentBuilderFactory.newInstance();

        try {
            xml.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            DocumentBuilder documentBuilder = xml.newDocumentBuilder();

            Document document = documentBuilder.parse(new File(filename));

            document.getDocumentElement().normalize();

            NodeList nodeList = document.getElementsByTagName("Planet");

            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    String ID = element.getElementsByTagName("ID").item(0).getTextContent();
                    String techLevelString = element.getElementsByTagName("TechnologyLevel").item(0).getTextContent();
                    int techLevel = Integer.parseInt(techLevelString);

                    List<String> neighbours = new ArrayList<>();

                    NodeList neighbours1 = element.getElementsByTagName("PlanetID");

                    for (int i = 0; i < neighbours1.getLength(); i++) {
                        Node taskNode = neighbours1.item(i);

                        if (taskNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element taskElement = (Element) taskNode;
                            String planetID = taskElement.getTextContent();
                            neighbours.add(planetID);

                        }
                    }
                    Planet planet = new Planet(ID,techLevel,neighbours);


                    planetList.add(planet);
                }
            }
        }catch(ParserConfigurationException | IOException | org.xml.sax.SAXException e){
            e.printStackTrace();
        }
        return new Galaxy(planetList);
    }
}
