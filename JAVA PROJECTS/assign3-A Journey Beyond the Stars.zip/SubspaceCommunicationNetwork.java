import java.util.*;

public class SubspaceCommunicationNetwork {

    private List<SolarSystem> solarSystems;

    /**
     * Perform initializations regarding your implementation if necessary
     * @param solarSystems a list of SolarSystem objects
     */
    public SubspaceCommunicationNetwork(List<SolarSystem> solarSystems) {
        // TODO: YOUR CODE HERE
        this.solarSystems = solarSystems;
    }

    /**
     * Using the solar systems of the network, generates a list of HyperChannel objects that constitute the minimum cost communication network.
     * @return A list HyperChannel objects that constitute the minimum cost communication network.
     */
    public List<HyperChannel> getMinimumCostCommunicationNetwork() {
        List<HyperChannel> minimumCostCommunicationNetwork = new ArrayList<>();
        List<Planet> maxTechnologyLevelPlanets = new ArrayList<>();
        // TODO: YOUR CODE HERE
        int V = solarSystems.size();
        for (int i = 0; i < V; i++) {
            int max = solarSystems.get(i).getPlanets().get(0).getTechnologyLevel();
            int m = 0;
            for (int j = 0; j < solarSystems.get(i).getPlanets().size(); j++) {
                if (max<solarSystems.get(i).getPlanets().get(j).getTechnologyLevel()){
                    max = solarSystems.get(i).getPlanets().get(j).getTechnologyLevel();
                    m = j;
                }
            }
            maxTechnologyLevelPlanets.add(solarSystems.get(i).getPlanets().get(m));
        }
        List<HyperChannel> allHyperChanels = new ArrayList<>();
        for(int i = 0; i < maxTechnologyLevelPlanets.size();i++){
            for (int j = i + 1 ; j < maxTechnologyLevelPlanets.size();j++) {
                double avg = maxTechnologyLevelPlanets.get(i).getTechnologyLevel() + maxTechnologyLevelPlanets.get(j).getTechnologyLevel();
                avg = avg / 2d ;
                double cost = Constants.SUBSPACE_COMMUNICATION_CONSTANT / avg;
                HyperChannel hyperChannel = new HyperChannel(maxTechnologyLevelPlanets.get(j), maxTechnologyLevelPlanets.get(i), cost);
                allHyperChanels.add(hyperChannel);
            }
        }
        Collections.sort(allHyperChanels, Comparator.comparing(HyperChannel::getWeight));
        List<Planet> toBeUsed = new ArrayList<>();
        int i = 0;
        while (minimumCostCommunicationNetwork.size()!=V-1){
            if(toBeUsed.contains(allHyperChanels.get(i).getTo())&&toBeUsed.contains(allHyperChanels.get(i).getFrom())){
                i++;
                continue;
            }
            toBeUsed.add(allHyperChanels.get(i).getTo());
            toBeUsed.add(allHyperChanels.get(i).getFrom());
            minimumCostCommunicationNetwork.add(allHyperChanels.get(i));
        }

        return minimumCostCommunicationNetwork;
    }

    public void printMinimumCostCommunicationNetwork(List<HyperChannel> network) {
        double sum = 0;
        for (HyperChannel channel : network) {
            Planet[] planets = {channel.getFrom(), channel.getTo()};
            Arrays.sort(planets);
            System.out.printf("Hyperchannel between %s - %s with cost %f", planets[0], planets[1], channel.getWeight());
            System.out.println();
            sum += channel.getWeight();
        }
        System.out.printf("The total cost of the subspace communication network is %f.", sum);
        System.out.println();
    }
}
