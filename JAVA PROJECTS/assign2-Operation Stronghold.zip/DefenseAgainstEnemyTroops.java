import java.util.ArrayList;

/**
 * This class accomplishes Mission Nuke'm
 */
public class DefenseAgainstEnemyTroops {
    private ArrayList<Integer> numberOfEnemiesArrivingPerHour;

    public DefenseAgainstEnemyTroops(ArrayList<Integer> numberOfEnemiesArrivingPerHour){
        this.numberOfEnemiesArrivingPerHour = numberOfEnemiesArrivingPerHour;
    }

    public ArrayList<Integer> getNumberOfEnemiesArrivingPerHour() {
        return numberOfEnemiesArrivingPerHour;
    }

    private int getRechargedWeaponPower(int hoursCharging){
        return hoursCharging*hoursCharging;
    }

    /**
     *     Function to implement the given dynamic programming algorithm
     *     SOL(0) <- 0
     *     HOURS(0) <- [ ]
     *     For{j <- 1...N}
     *         SOL(j) <- max_{0<=i<j} [ (SOL(i) + min[ E(j), P(j − i) ] ]
     *         HOURS(j) <- [HOURS(i), j]
     *     EndFor
     *
     * @return OptimalEnemyDefenseSolution
     */
    public OptimalEnemyDefenseSolution getOptimalDefenseSolutionDP(){
        // TODO: YOUR CODE HERE

        int[] SOL = new int[numberOfEnemiesArrivingPerHour.size()+1];
        SOL[0]  = 0;

        ArrayList<Integer>[] HOURS = new ArrayList[numberOfEnemiesArrivingPerHour.size()+1];
        HOURS[0] = new ArrayList<>();

        for (int j = 1; j <= numberOfEnemiesArrivingPerHour.size(); j++){
            int numberMaxKilled = 0;
            for (int i = 0; i < j; i++){
                int currentKilled = SOL[i] + Math.min(numberOfEnemiesArrivingPerHour.get(j-1), getRechargedWeaponPower(j-i));
                if (currentKilled > numberMaxKilled){
                    SOL[j] = currentKilled;
                    ArrayList<Integer> temp = new ArrayList<>(HOURS[i]);
                    temp.add(j);
                    HOURS[j] = temp;
                    numberMaxKilled = currentKilled;
                }
            }
        }
        OptimalEnemyDefenseSolution returnThat = new OptimalEnemyDefenseSolution(SOL[numberOfEnemiesArrivingPerHour.size()], HOURS[numberOfEnemiesArrivingPerHour.size()]);
        return returnThat;
    }
}
