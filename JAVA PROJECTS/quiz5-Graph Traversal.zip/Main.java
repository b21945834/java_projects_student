import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main {
    public static Boolean hasLoop; // DO NOT change or delete this line! USED FOR AUTOGRADING!
    public static int totalSteps; // DO NOT change or delete this line! USED FOR AUTOGRADING!
    public static int loopSteps; // DO NOT change or delete this line! USED FOR AUTOGRADING!
    public static ArrayList<ArrayList<Integer>> visited = new ArrayList<>();
    public static int row;
    public static int column;
    public static void main(String args[]) throws IOException{

        // Your code here
        // TODO: Implement the problem here such that the member variables
        // TODO: hasLoop, totalSteps, and loopSteps declared above will be
        // TODO: assigned the proper values when your code executes
        // TODO: and the expected output will be given to STDOUT
        BufferedReader bufferedReader = new BufferedReader(new FileReader(args[0]));

        String line = bufferedReader.readLine();
        row = Integer.parseInt(line.split(" ")[0]);
        column = Integer.parseInt(line.split(" ")[1]);
        int start = Integer.parseInt(line.split(" ")[2]);
        char[][] map = new char[row][column];

        totalSteps = 0;

        for (int i = 0; i < row; i++) {
            line = bufferedReader.readLine();
            for (int j = 0; j < column; j++) {
                map[i][j] = line.charAt(j);
            }
        }
        gez(map,0,start-1);
    }
    public static int gez(char[][] map, int row, int col){


        for (int i = 0; i < visited.size(); i++) {
            if (visited.get(i).get(0)==row && visited.get(i).get(1) == col){
                hasLoop = true;
                totalSteps = visited.size();
                loopSteps = totalSteps - i;
                System.out.println(i + " step(s) before getting stuck in a loop of " + loopSteps + " step(s)");
                return 1;
            }
        }
        ArrayList<Integer> initialVisit = new ArrayList<>();
        initialVisit.add(row);
        initialVisit.add(col);
        visited.add(initialVisit);
        if (row < 0 || Main.row <= row || col < 0 || col >= column){
            totalSteps += 1;
            System.out.println(totalSteps-1 + " step(s) to freedom. Yay!");
            return -1;
        }

        if(map[row][col]=='U'){
            totalSteps +=1;
            return gez(map,row-1,col);
        }
        if (map[row][col]=='D'){
            totalSteps += 1;
            return gez(map,row+1,col);
        }
        if (map[row][col]=='R'){
            totalSteps += 1;
            return gez(map,row,col+1);
        }
        if (map[row][col]=='L'){
            totalSteps += 1;
            return gez(map,row,col-1);
        }
        return -1;
    }

}
