import java.io.File;
import java.util.*;

public class Main {
    static int output = 0;
    public static void main(String[] args) {


        int[][] maze = null;
        int[] sizes = new int[2];
        int[] goal = new int[2];

        try {
            File myObj = new File(args[0]);
            Scanner myReader = new Scanner(myObj);

            String strSize = myReader.nextLine();
            String[] strSizeArray = strSize.split(" ");
            sizes[0]= Integer.parseInt(strSizeArray[0]);
            sizes[1] = Integer.parseInt(strSizeArray[1]);

            maze = new int[sizes[0]][sizes[1]];
            for(int i = 0 ; i<sizes[0];i++){
                String mazeRow = myReader.nextLine();
                String[] mazeRowArray = mazeRow.split(" ");
                int columnIndex = 0;
                for(String value : mazeRowArray){
                    maze[i][columnIndex] = Integer.parseInt(value);
                    columnIndex +=1;
                }
            }

            String goalLine = myReader.nextLine();
            String[] goalArray = goalLine.split(" ");
            goal[0] = Integer.parseInt(goalArray[0]);
            goal[1] = Integer.parseInt(goalArray[1]);


            myReader.close();
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


        System.out.println(solve(maze,goal,sizes));



    }

    public static int solve(int[][] maze, int[] goal, int[] sizes) {

        int initialRow = 0;
        int initialColumn = 0;
        recursiveSolve(maze,goal,sizes,initialRow,initialColumn);



        // TODO fill this function

        //Return the result
        return output;
    }

    public static void recursiveSolve(int[][] maze, int[] goal, int[] sizes, int initialRow, int initialColumn){
        int goToDownThatMuch = goal[0]-initialRow;
        int goToRightThatMuch = goal[1]-initialColumn;

        if(goToRightThatMuch ==0 && goToDownThatMuch==0) {
            output +=1;
        }
        if(initialRow+1<sizes[0] && maze[initialRow+1][initialColumn] !=1 && goToDownThatMuch != -1 && goToRightThatMuch != -1){
            recursiveSolve(maze,goal,sizes,initialRow+1,initialColumn);
        }
        if(initialColumn+1<sizes[1] && maze[initialRow][initialColumn+1] != 1 && goToRightThatMuch != -1 && goToDownThatMuch != -1){
            recursiveSolve(maze,goal,sizes,initialRow,initialColumn+1);
        }
    }
}
