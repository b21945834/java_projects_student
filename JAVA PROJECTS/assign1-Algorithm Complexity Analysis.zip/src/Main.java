import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

class Main {
    static String[] sortMethods = {"insertion","merge","pigeonhole","counting"};
    static int[] arrayToBeSorted;
    static int[] sizeOfInputs = {512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 251281};
    static double[] randomExecutionTimeForInsertion = new double[10];
    static double[] randomExecutionTimeForMerge = new double[10];
    static double[] randomExecutionTimeForPigeonhole = new double[10];
    static double[] randomExecutionTimeForCounting = new double[10];

    static double[] sortedExecutionTimeForInsertion = new double[10];
    static double[] sortedExecutionTimeForMerge = new double[10];
    static double[] sortedExecutionTimeForPigeonhole = new double[10];
    static double[] sortedExecutionTimeForCounting = new double[10];

    static double[] reverseExecutionTimeForInsertion = new double[10];
    static double[] reverseExecutionTimeForMerge = new double[10];
    static double[] reverseExecutionTimeForPigeonhole = new double[10];
    static double[] reverseExecutionTimeForCounting = new double[10];

    static double[][] randomTimes = new double[4][10];
    static double[][] sortedTimes = new double[4][10];
    static double[][] reverseTimes = new double[4][10];

    public static void main(String args[]) throws IOException {

        // X axis data
        int[] inputAxis = {512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 251282};

        // Save the char as .png and show it
        RandomSort(args);
        randomTimes[0] = randomExecutionTimeForInsertion.clone();
        randomTimes[1] = randomExecutionTimeForMerge.clone();
        randomTimes[2] = randomExecutionTimeForPigeonhole.clone();
        randomTimes[3] = randomExecutionTimeForCounting.clone();
        showAndSaveChart("Random", inputAxis, randomTimes);
        SortedSort(args);
        sortedTimes[0] = sortedExecutionTimeForInsertion.clone();
        sortedTimes[1] = sortedExecutionTimeForMerge.clone();
        sortedTimes[2] = sortedExecutionTimeForPigeonhole.clone();
        sortedTimes[3] = sortedExecutionTimeForCounting.clone();
        showAndSaveChart("Sorted", inputAxis,sortedTimes);
        ReverseSort(args);
        reverseTimes[0] = reverseExecutionTimeForInsertion.clone();
        reverseTimes[1] = reverseExecutionTimeForMerge.clone();
        reverseTimes[2] = reverseExecutionTimeForPigeonhole.clone();
        reverseTimes[3] = reverseExecutionTimeForCounting.clone();
        showAndSaveChart("Reverse", inputAxis,reverseTimes);
    }
    public static void RandomSort(String args[]) throws IOException {
        int sayac=0;
        for (String method : sortMethods) {
            int index = 0;
            for (int size : sizeOfInputs) {
                double time = MainSort(args,method,size,"random");
                if(method.equals("insertion")) {randomExecutionTimeForInsertion[index] = time;}
                else if(method.equals("merge")) {randomExecutionTimeForMerge[index] = time;}
                else if(method.equals("pigeonhole")) {randomExecutionTimeForPigeonhole[index] = time;}
                else if(method.equals("counting")) {randomExecutionTimeForCounting[index] = time;}
                index++;
            }
        if (method.equals("counting")){
            sayac +=1;
        }
        }
    }
    public static void SortedSort(String args[]) throws IOException {
        for (String method : sortMethods) {
            int index = 0;
            for (int size : sizeOfInputs) {
                double time = MainSort(args,method,size,"sorted");
                if(method.equals("insertion")) sortedExecutionTimeForInsertion[index] = time;
                else if(method.equals("merge")) sortedExecutionTimeForMerge[index] = time;
                else if(method.equals("pigeonhole")) sortedExecutionTimeForPigeonhole[index] = time;
                else if(method.equals("counting")) sortedExecutionTimeForCounting[index] = time;
                index++;
            }
        }
    }
    public static void ReverseSort(String args[]) throws IOException {
        for (String method : sortMethods) {
            int index = 0;
            for (int size : sizeOfInputs) {
                double time = MainSort(args,method,size,"reverse");
                if(method.equals("insertion")) reverseExecutionTimeForInsertion[index] = time;
                else if(method.equals("merge")) reverseExecutionTimeForMerge[index] = time;
                else if(method.equals("pigeonhole")) reverseExecutionTimeForPigeonhole[index] = time;
                else if(method.equals("counting")) {
                    reverseExecutionTimeForCounting[index] = time;}
                index++;
            }
        }
    }

    public static double MainSort(String args[],String sortMethod,int sizeOfToBeSorted, String mode) throws IOException {
        BufferedReader file = new BufferedReader(new FileReader(args[0]));
        file.readLine();
        String line;
        arrayToBeSorted = new int[sizeOfToBeSorted];
        for (int i = 0; i < arrayToBeSorted.length; i++) {
            line = file.readLine();
            arrayToBeSorted[i] = Integer.parseInt(line.split(",")[7]);
        }

        MergeSort mergeSort = new MergeSort();
        InsertionSort insertionSort = new InsertionSort();
        PigeonholeSort pigeonholeSort = new PigeonholeSort();
        CountingSort countingSort = new CountingSort();
        if(mode.equals("sorted") || mode.equals("reverse")){
            mergeSort.sort(arrayToBeSorted,0,sizeOfToBeSorted-1);
        }
        int[] arrayToBeReversed = arrayToBeSorted.clone();
        int reversed = 0;
        if(mode.equals("reverse")){
            for (int i = 0; i < sizeOfToBeSorted; i++) {
                reversed = 1;
                arrayToBeSorted[sizeOfToBeSorted-i-1] = arrayToBeReversed[i];
            }
        }
        if(reversed==1){
            reversed = 2;
        }
        if(sortMethod.equals("insertion")){
            long startTime = System.nanoTime();
            insertionSort.sort(arrayToBeSorted);
            long endTime = System.nanoTime();
            long elapsedTime = endTime - startTime;
            return elapsedTime / 1000000.0;
        }
        else if(sortMethod.equals("merge")){
            long startTime = System.nanoTime();
            mergeSort.sort(arrayToBeSorted,0,sizeOfToBeSorted-1);
            long endTime = System.nanoTime();
            long elapsedTime = endTime - startTime;
            return elapsedTime / 1000000.0;
        }
        else if(sortMethod.equals("pigeonhole")){
            long startTime = System.nanoTime();
            pigeonholeSort.sort(arrayToBeSorted,sizeOfToBeSorted);
            long endTime = System.nanoTime();
            long elapsedTime = endTime - startTime;
            return elapsedTime / 1000000.0;
        }
        else{
            long startTime = System.nanoTime();
            countingSort.sort(arrayToBeSorted);
            long endTime = System.nanoTime();
            long elapsedTime = endTime - startTime;
            return elapsedTime / 1000000.0;
        }
    }

    public static void showAndSaveChart(String title, int[] xAxis, double[][] yAxis) throws IOException {
        // Create Chart
        XYChart chart = new XYChartBuilder().width(800).height(600).title(title)
                .yAxisTitle("Time in Milliseconds").xAxisTitle("Input Size").build();

        // Convert x axis to double[]
        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

        // Add a plot for a sorting algorithm
        chart.addSeries("Insertion", doubleX, yAxis[0]);
        chart.addSeries("Merge", doubleX, yAxis[1]);
        chart.addSeries("Pigeonhole", doubleX, yAxis[2]);
        chart.addSeries("Counting", doubleX, yAxis[3]);

        // Save the chart as PNG
        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);

        // Show the chart
        new SwingWrapper(chart).displayChart();
    }
}

